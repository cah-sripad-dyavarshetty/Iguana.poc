function main(Data)
   -- Parse the JSON message
   local Msg = xml.parse(Data)  
   
   -- (1) connect to the database
   
   -- (2) create insert query string
      
   -- (3) Insert data into database
end